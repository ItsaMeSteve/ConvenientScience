import 'package:flutter/material.dart';
import 'facts_individual.dart';
import 'package:cc_info/myths.dart';
import 'package:webview_flutter/webview_flutter.dart';

class FactsPage extends StatelessWidget {
  static const String id = 'facts_screen';
  //Myths testData;
  //testData = testData.getData();

  final List<int> colorCodes = <int>[600, 500, 100];

  void selectFact(BuildContext ctx, int id, String title) {
    Navigator.of(ctx).push(MaterialPageRoute(
      builder: (_) {
        return FactsIndividual(id, title);
      },
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Wrap(
            direction: Axis.horizontal,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(
                    'Here is a summary of global warming and climate change myths, sorted by recent popularity vs what science says. '
                    'Click the response for a more detailed response. You can also view them sorted by taxonomy, by popularity, in a print-friendly version, '
                    'with short URLs or with fixed numbers you can use for permanent references.'),
              ),
            ],
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(8),
              itemCount: testData.length,
              itemBuilder: (BuildContext context, int index) {
                return InkWell(
                  //InkWell is required because Container doesn't support gestures
                  onTap: () => selectFact(context, testData[index].dbEntry,
                      testData[index].mythSays),
                  splashColor: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.circular(15),
                  child: Container(
                    height: 50,
                    //color: Colors.amber[colorCodes[index]],
                    color: Colors.amber[100],

                    child: Center(child: Text('${testData[index].mythSays}')),
                  ),
                );
              },
              separatorBuilder: (BuildContext context, int index) =>
                  const Divider(),
            ),
          ),
        ],
      ),
    );
  }
}
