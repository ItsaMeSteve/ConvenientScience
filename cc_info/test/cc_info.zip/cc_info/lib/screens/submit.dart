import 'package:flutter/material.dart';

class SubmitPage extends StatelessWidget {
  static const String id = 'submit_screen';

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('Submit page'),
    );
  }
}
