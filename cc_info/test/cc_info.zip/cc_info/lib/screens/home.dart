import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  static const String id = 'home_screen';
  final String introText = "";

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Convenient Science',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Text(
                    "A scientific look at climate change.  No distortion, no propoganda, "
                    "just a real evaluation of what the evidence is telling us.\n\n"
                    // This was stolen from Skeptical Science
                    // Need to change later on before publishing
                    "Scientific skepticism is healthy. Scientists should always challenge "
                    "themselves to improve their understanding. Yet this isn't what happens "
                    "with climate change denial. Skeptics vigorously criticise any evidence "
                    "that supports man-made global warming and yet embrace any argument, op-ed, "
                    "blog or study that purports to refute global warming. This website gets "
                    "skeptical about global warming skepticism. Do their arguments have any "
                    "scientific basis? What does the peer reviewed scientific literature say?"),
              ),
            ],
          ),
        ], //children: <Widget>
      ),
    );
  }
}
