import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/services.dart';
import 'dart:convert';

class FactsIndividual extends StatelessWidget {
  static const String id = 'facts_individual';

  final int categoryID;
  final String categoryTitle;
  WebViewController _controller;

  Future<void> loadHtmlFromAssets(String filename, controller) async {
    String fileText = await rootBundle.loadString(filename);
    controller.loadUrl(Uri.dataFromString(fileText,
            mimeType: 'text/html', encoding: Encoding.getByName('utf-8'))
        .toString());
  }

  FactsIndividual(this.categoryID, this.categoryTitle);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(categoryTitle)),
      body: Container(
        height: 1000,
        child: ListView(
          children: <Widget>[
            Row(
              //mainAxisSize: MainAxisSize.max,
              //crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(
                  child: FlatButton(
                    onPressed: () {},
                    child: Text("Basic"),
                    color: Colors.blue,
                    padding: EdgeInsets.all(10),
                  ),
                ),
                Expanded(
                  child: FlatButton(
                    onPressed: () {},
                    child: Text("Intermediate"),
                    color: Colors.blue,
                    padding: EdgeInsets.all(10),
                  ),
                ),
                Expanded(
                  child: FlatButton(
                    onPressed: () {},
                    child: Text("Advanced"),
                    color: Colors.blue,
                    padding: EdgeInsets.all(10),
                  ),
                ),
              ],
            ),
            Row(
              children: <Widget>[
                Text("What the science says"),
              ],
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                      "In the last 35 years of global warming, the sun has shown a slight cooling trend. Sun and climate have been going in opposite directions. In the past century, the Sun can explain some of the increase in global temperatures, but a relatively small amount."),
                ),
              ],
            ),
            //Spacer(flex: 2),
            Row(
              children: <Widget>[
                Text("Climate Myth..."),
              ],
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                      "It's the sun.  Over the past few hundred years, there has been a steady increase in the numbers of sunspots, at the time when the Earth has been getting warmer. The data suggests solar activity is influencing the global climate causing the world to get warmer. (BBC)"),
                )
              ],
            ),
            //Spacer(flex: 2),
            WebView(
              initialUrl: '',
              onWebViewCreated: (WebViewController webViewController) async {
                _controller = webViewController;
                await loadHtmlFromAssets('lib/data/test.html', _controller);
              },
            ),
            Text(categoryID.toString()),
          ],
        ),
      ),
    );
  }
}
