import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  static const String id = 'about_screen';

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('About page'),
    );
  }
}
