import 'package:cc_info/screens/facts.dart';
import 'package:flutter/material.dart';
import 'screens/home.dart';
import 'screens/facts.dart';
import 'screens/submit.dart';
import 'screens/about.dart';

void main() => runApp(ConvenientTruths());

class ConvenientTruths extends StatelessWidget {
  static const String id = 'main_screen';

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Convenient Science',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: AppMain(title: 'Convenient Science'),
    );
  }
}

class AppMain extends StatefulWidget {
  final String title;
  AppMain({Key key, this.title}) : super(key: key);

  @override
  _AppMainState createState() => _AppMainState();
}

class _AppMainState extends State<AppMain> {
  int _selectedPage = 0;

  final _topLevelPages = [
    HomePage(),
    FactsPage(),
    SubmitPage(),
    AboutPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: _topLevelPages[_selectedPage],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedPage,
        type: BottomNavigationBarType.fixed,
        //backgroundColor: Colors.lightBlue,
        iconSize: 30,
        onTap: (index) {
          setState(() {
            _selectedPage = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            title: Text('Home'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.lightbulb_outline),
            title: Text('Myths'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.camera),
            title: Text('Submit'),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.people),
              title: Text('About Us'),
              backgroundColor: Colors.blue),
        ],
      ),
    );
  }
}
